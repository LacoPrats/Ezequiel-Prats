import React from 'react';
import './header.css';
import Headersocials from './Headersocials';
import HeaderContact from '../Headercontact/Headercontact';

const Header = () => {
  return (
    <header className='header'>
      <HeaderContact/>
      <div className="container header__container">
        <div className="header__text">
          <h1>Ezequiel Prats</h1>
          <div className='header__titles'>
          <h5 className="text-light">Front End Developer</h5>
          <h5 className="text-light">UX UI Designer</h5>
          </div>
          <Headersocials />
          <a href="#contact" className="scroll_down">Scroll Down</a>
        </div>
      </div>
    </header>
  );
}

export default Header;
